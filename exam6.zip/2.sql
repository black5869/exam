POST /employee/_search
{
  "query": {
    "match_all": {}
  }
}