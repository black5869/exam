/**
 * 
 */
package exam;

import java.util.*;

/**
 * @author user
 *
 */
public class S3 {
public static void main(String[] args) {
	 Scanner a = new Scanner(System.in);
	    int N = a.nextInt();
	    int[] c = new int[N];
        Random e = new Random();

        for (int i = 0; i < N; i++) {
            c[i] = e.nextInt(10) + 1;
        }

        for (int d : c) {
            System.out.print(d + " ");
        }
        System.out.println();

        Arrays.sort(c);

        for (int d : c) {
            System.out.print(d + " ");
        }
        System.out.println();

        a.close();
	   
}
}
