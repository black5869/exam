<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c"      uri="http://java.sun.com/jsp/jstl/core" %>

<html>
<head>
    <title>Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- 	부트스트랩 css  -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <!-- 	개발자 css -->
    <link rel="stylesheet" href="/css/style.css">

</head>
<body>
<jsp:include page="/common/header.jsp"/>
${faq}
<div class="page mt3">
    <form id="addForm" name="addForm" method="post">
        <%--        기본키(숨김) --%>
        <input type="hidden" name="fno" value="<c:out value='${faq.fno}' />">
        <div class="mb3">
            <label for="title" class="form-label">title</label>
            <input type="text"
                   class="form-control"
                   id="title"
                   name="title"
                   value="<c:out value='${faq.title}' />"
                   placeholder="title" />
        </div>
        <div class="mb3">
            <label for="content" class="form-label">content</label>
            <input type="text"
                   class="form-control"
                   id="content"
                   name="content"
                   value="<c:out value='${faq.content}' />"
                   placeholder="content" />
        </div>
        <div class="mb3">
            <button type="button"
                    class="btn btn-warning"
                    onclick="fn_save()"
            >수정</button>

            <button type="button"
                    class="btn btn-danger"
                    onclick="fn_delete()"
            >삭제</button>
        </div>
    </form>
</div>
<!-- jquery -->
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<!-- 부트스트랩 js -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

<script>
    function fn_save() {
        /* 의미: addForm 태그를 선택해서 속성 action 의 값을 /faq/edit 변경 */
        $("#addForm").attr("action","/faq/edit")
            .submit();
    }
    function fn_delete() {
        /* 의미: addForm 태그를 선택해서 속성 action 의 값을 /faq/delete 변경 */
        $("#addForm").attr("action","/faq/delete")
            .submit();
    }
</script>

<jsp:include page="/common/footer.jsp"/>
</body>
</html>
