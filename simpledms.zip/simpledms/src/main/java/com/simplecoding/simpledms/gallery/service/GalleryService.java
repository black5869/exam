package com.simplecoding.simpledms.gallery.service;

import com.simplecoding.simpledms.common.ErrorMsg;
import com.simplecoding.simpledms.common.MapStruct;
import com.simplecoding.simpledms.gallery.dto.GalleryDto;
import com.simplecoding.simpledms.gallery.entity.Gallery;
import com.simplecoding.simpledms.gallery.repository.GalleryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class GalleryService {
    private final GalleryRepository galleryRepository;
    private final MapStruct mapStruct;       // 복사 라이브러리
    private final ErrorMsg errorMsg;         // 에러메세지 화면표시 클래스

    //    전체조회
    public Page<GalleryDto> selectGalleryList(String searchKeyword,
                                              Pageable pageable) {
        Page<Gallery> page = galleryRepository.selectGalleryList(searchKeyword, pageable);
//        TODO: .map(람다식): 스트림의 자동반복문 함수, 람다식을 배열의 개수만큼 자동 반복하는 함수
        return page.map(data -> mapStruct.toDto(data));
    }

//    1. DB 에 이미지 저장 관리(장점: 유지보수 편함,성능 좀 낮음, 비용 증가)
//    => 컴퓨터 이전시 DB 백업에서 옮기면 끝(편함)
//    => DB 저장않하는 방법: 성능좋음, DB 백업, 다른 컴퓨터도 백업 등(관리 어려움)
//    추가: 1) DB 이미지 저장
//         2) 이미지 다운로드 URL 만들기
//    참고) 2. AWS(짱) 에 이미지 저장(성능 좋음, 편함)

    //    저장
    public void save(GalleryDto galleryDto, byte[] image) {
//      1) Dto -> 엔티티 복사
        Gallery gallery = mapStruct.toEntity(galleryDto);
//      2) 기본키: UUID 만들기
        String newUuid = UUID.randomUUID().toString();
//      3) 이미지를 다운로드하는 URL 만들기: 기본키로(uuid) 만듬
        String downloadUrl = generateDownloadUrl(newUuid);
//      4) setter 위의 정보 넣기
        gallery.setUuid(newUuid);
        gallery.setGalleryFileUrl(downloadUrl);
        gallery.setGalleryData(image);
//      5) 저장
        galleryRepository.save(gallery);
    }

    //    이미지를 다운로드하는 URL 만들어주는 함수
    public String generateDownloadUrl(String uuid) {
        return ServletUriComponentsBuilder
                .fromCurrentContextPath()     // 기본주소 : http://localhost:8080
                .path("/gallery/download")  // 경로    : /fileDb/download
                .query("uuid=" + uuid)          // 쿼리스트링: ?uuid=uuid값
                .toUriString();               // 위에꺼조합:
        // http://localhost:8080/gallery/download?uuid=uuid값
    }

    //    상세조회: (리턴: Gallery(엔티티 리턴))
    public Gallery findById(String uuid) {
        return galleryRepository.findById(uuid)
                .orElseThrow(() -> new RuntimeException(errorMsg.getMessage("errors.not.found")));
    }
    //    삭제
    public void deleteById(String uuid) {
        galleryRepository.deleteById(uuid);
    }
}











