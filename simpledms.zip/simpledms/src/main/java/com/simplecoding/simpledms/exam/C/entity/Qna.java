package com.simplecoding.simpledms.exam.C.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "TB_QNA")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Qna {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer qno;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false)
    private String content;

    private String writer;

    private String answer;

    private String deleteYn;
}