package com.simplecoding.simpledms.exam;

public class B {

//    import lombok.RequiredArgsConstructor;
//    import org.springframework.web.bind.annotation.RestController;
//
//    @RestController
//    @RequiredArgsConstructor
//    public class DeptController {
//        //        서비스 가져오기
//        private DeptService deptService;
//...
//    }
}
