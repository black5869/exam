package com.simplecoding.simpledms.exam;

public class A {
//    DI는 Dependency Injection의 약자로 의존성 주입입니다. 필요한 객체(의존성)를 외부에서 주입해주는 것입니다. IoC의 구현 방식 중 하나입니다.

//    IOC는 Inversion of Control의 약자로 객체 생성과 제어 권한을 개발자가 아닌 스프링이 담당하는 것입니다.
//    원래는 개발자가 new로 객체를 직접 만들고 연결해야 하는데, 스프링이 대신 생성하고 필요한 객체를 주입해줍니다.

//    AOP는 Aspect Oriented Programming의 약자로 관점 지향 프로그래밍입니다. 공통 기능을 핵심 로직과 분리해서 재사용하는 방식입니다.
//    반복되는 코드를 핵심 로직에서 분리해서 관리하는것을 말합니다.

}
