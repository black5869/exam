package com.simplecoding.simpledms.exam.C.repository;

import com.simplecoding.simpledms.exam.C.entity.Qna;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface QnaRepository extends JpaRepository<Qna, Integer> {
}
