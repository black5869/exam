package com.simplecoding.simpledms.exam.C.dto;

import lombok.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class QnaDto {
    private Long qno;
    private String questioner;
    private String question;
    private String answer;
    private String answerer;
    private LocalDateTime insertTime;
    private LocalDateTime updateTime;
}
