package com.simplecoding.simpledms.exam.C.controller;

import com.simplecoding.simpledms.exam.C.entity.Qna;
import com.simplecoding.simpledms.exam.C.service.QnaService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@Log4j2
@Controller
public class QnaController {

    private final QnaService qnaService;


    @GetMapping("/qna")
    @ResponseBody
    public Page<Qna> list(@PageableDefault(size = 10) Pageable pageable) {
        return qnaService.findAll(pageable);
    }


    @PostMapping("/qna")
    @ResponseBody
    public Qna write(@RequestBody Qna qna) {
        return qnaService.writeQna(qna);
    }
}
