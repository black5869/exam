package com.simplecoding.simpledms.exam.C.service;

import com.simplecoding.simpledms.exam.C.entity.Qna;
import com.simplecoding.simpledms.exam.C.repository.QnaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor
@Service
public class QnaService {

    private final QnaRepository qnaRepository;


    public Page<Qna> findAll(Pageable pageable) {
        return qnaRepository.findAll(pageable);
    }


    public Qna writeQna(Qna qna) {
        return qnaRepository.save(qna);
    }
}
