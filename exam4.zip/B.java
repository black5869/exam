/**
 * 
 */
package egovframework.example.exam4;



/**
 * @author user
 * @Log4j2
 * @Controller
   public class DeptController {
//        서비스 가져오기
 * @Autowired
       private DeptService deptService; 
...
}
 */
public class B {

}
