/**
 * 
 */
package egovframework.example.exam4.C.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import egovframework.example.common.Criteria;
import egovframework.example.exam4.C.Service.DbService;
import lombok.extern.log4j.Log4j2;

/**
 * @author user
 *
 */
@Log4j2
@Controller
public class DbController {
	@Autowired
	private DbService dbService;
	@GetMapping("/db/db.do")
	public String selectDbList(@ModelAttribute Criteria criteria, Model model) {
	List<?> dbs = dbService.selectDbList(criteria);
	log.info("테스트 : " + dbs);
	model.addAttribute("dbs", dbs);
	return "db/db_all";
	}
}
