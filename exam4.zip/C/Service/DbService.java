/**
 * 
 */
package egovframework.example.exam4.C.Service;

import java.util.List;

import egovframework.example.common.Criteria;

/**
 * @author user
 *
 */
public interface DbService {
	List<?> selectDbList(Criteria criteria);
}
