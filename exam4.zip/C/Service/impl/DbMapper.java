/**
 * 
 */
package egovframework.example.exam4.C.Service.impl;

import java.util.List;

import egovframework.example.common.Criteria;

/**
 * @author user
 *
 */
public interface DbMapper {
	public List<?> selectDbList(Criteria criteria);
}
