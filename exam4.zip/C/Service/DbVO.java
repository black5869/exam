/**
 * 
 */
package egovframework.example.exam4.C.Service;

import egovframework.example.common.Criteria;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author user
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode(callSuper = false)
public class DbVO extends Criteria {
//	FNO	NUMBER
//	TITLE	VARCHAR2(255 BYTE)
//	CONTENT	VARCHAR2(255 BYTE)
	private int fno;       
	private String title;  
	private String content;    
}
