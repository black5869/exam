/**
 * 
 */
package egovframework.example.exam4;

/**
 * @author user
 * 스프링 MVC 디자인 패턴은  SPRING M(MODEL)/V(VIEW)/C(CONTROLLER)로 
 * 자바 소스를 나누어 관리합니다.
 * 3가지는 아래와 같이 목적에 따른 코딩을 합니다.
 *  M(MODEL) 데이터를 저장하고 제공하는 코딩을 합니다.
 *  V(VIEW) 화면에 관련된 코딩을 합니다.
 *  C(CONTROLLER)는 URL과 화면을 연결해주고 
 *  MODEL에서 전달받은 데이터를 보내주기도 합니다.
 */
public class A {

}
