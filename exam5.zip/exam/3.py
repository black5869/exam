import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager

# 자동으로 chromedriver.exe 설치 및 실행
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=Options())

# 로그인 페이지 접속
driver.get("https://www.saucedemo.com/")

# 사용자명 입력
driver.find_element(By.ID, "user-name").send_keys("standard_user")
# 비밀번호 입력
driver.find_element(By.ID, "password").send_keys("secret_sauce")
# 로그인 버튼 클릭
driver.find_element(By.CSS_SELECTOR, 'input[type="submit"]').click()

# 로그인 결과 확인
time.sleep(1)
print("현재URL:", driver.current_url)

# 로그인 후 첫 페이지에 나오는 모든 상품 정보(이름 + 설명 + 가격) 표시
items = driver.find_elements(By.CLASS_NAME, "inventory_item")

for item in items:
    name = item.find_element(By.CLASS_NAME, "inventory_item_name").text
    desc = item.find_element(By.CLASS_NAME, "inventory_item_desc").text
    price = item.find_element(By.CLASS_NAME, "inventory_item_price").text
    print(f"상품: {name}\n설명: {desc}\n가격: {price}\n")

# 끝내기
driver.quit()
